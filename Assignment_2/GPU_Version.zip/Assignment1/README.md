This template is intended for students of Utrecht University.

**Please refer to "_ getting started.pdf" for instructions.**

Code is fully public domain. Use as you please.

Contact me at bikker.j@gmail.com.
