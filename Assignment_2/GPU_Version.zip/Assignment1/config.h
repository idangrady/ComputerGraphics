#pragma once
#define STATIC 1
#define PRETTY 0
#define GPU //comment this part to turn off GPU

bool sendWhittedCONFIG = false; 
uint8_t AA_COUNT = 1;
int MAX_DEPTH = 20;

int pocketSize = 10;		// The amount of checks simultanesely 